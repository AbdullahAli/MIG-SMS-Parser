package mig_voting_parser;
import java.awt.Color;
import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 * 
 * @author Abdullah
 * 
 * This class is used the main GUI - allowing the user to interact with the system.
 * Most of the methods are auto-generated.
 */
public class MainGUI extends javax.swing.JFrame 
{
    /** a boolean value to determine if the user has imported  file 
     * and hence can launch the website.
     */
    private boolean canLaunchWebsite = false;
    
    /**
     * Constructor - update the GUI and display it.
     */
    public MainGUI() 
    {     
        initComponents();
        updateGUI();        
    }
    
    /**
     * Used to get the file the user has section.
     * @return - return the file the user has selected.  May return null if no file was selected.
     */
    public File getChosenFile()
    {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(this);
        if(result != JFileChooser.CANCEL_OPTION && fileChooser.getSelectedFile() != null)
        {
            return fileChooser.getSelectedFile();
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        textPane = new javax.swing.JScrollPane();
        progressText = new javax.swing.JTextArea();
        btnLaunchWebsite = new javax.swing.JButton();
        btnImport = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("MIG SMS Parser");

        jLayeredPane1.setBackground(new java.awt.Color(255, 255, 255));

        textPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        textPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        progressText.setColumns(20);
        progressText.setEditable(false);
        progressText.setRows(5);
        progressText.setText("Waiting for user to select a file...");
        progressText.setBorder(null);
        textPane.setViewportView(progressText);

        textPane.setBounds(180, 102, 200, 100);
        jLayeredPane1.add(textPane, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btnLaunchWebsite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLaunchWebsiteActionPerformed(evt);
            }
        });
        btnLaunchWebsite.setBounds(400, 160, 90, 70);
        jLayeredPane1.add(btnLaunchWebsite, javax.swing.JLayeredPane.DEFAULT_LAYER);

        btnImport.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btnImport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImportActionPerformed(evt);
            }
        });
        btnImport.setBounds(400, 0, 90, 160);
        jLayeredPane1.add(btnImport, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mig_voting_parser/importImage.png"))); // NOI18N
        jLabel2.setText("dfsdfsdf");
        jLabel2.setToolTipText("");
        jLabel2.setBounds(0, 0, 500, 230);
        jLayeredPane1.add(jLabel2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 498, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-514)/2, (screenSize.height-267)/2, 514, 267);
    }// </editor-fold>//GEN-END:initComponents

    private void btnImportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImportActionPerformed
        //reset the status text.
        progressText.setText("");
        File file = getChosenFile();
        
        //if file is not null, attempt to parse it.
        if(file != null)
        {
            Parser x = new Parser(file.getPath(), this);
        }
        else
        {
            updateProgressText("No File selected.");
        }
    }//GEN-LAST:event_btnImportActionPerformed

    private void btnLaunchWebsiteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLaunchWebsiteActionPerformed
       //if user has imported a file
       if(canLaunchWebsite)
       {
            try {
                try {
                    //open the default browser - whatever that may be.
                    Desktop.getDesktop().browse(new URI("http://localhost/AbdullahAli/votes.php"));
                } catch (URISyntaxException ex) {
                    Logger.getLogger(MainGUI.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (IOException ex) {
                Logger.getLogger(MainGUI.class.getName()).log(Level.SEVERE, null, ex);
            }
           this.dispose();
           System.out.println("Launched website");
       }
       else
       {
           //ask the user to import a file first.
           JOptionPane.showMessageDialog(null, "Please import a file first.", "Error", JOptionPane.ERROR_MESSAGE); 
       }
    }//GEN-LAST:event_btnLaunchWebsiteActionPerformed

    /**
     * Sets if the flag used to determine if the website can be launched.
     * @param status - used to determine if website can be launched.
     */
    public void setCanLaunchWebsite(boolean status)
    {
        canLaunchWebsite = status;
    }
    
    /**
     * Used to update the progress/ status text
     * @param message - the new line of message.
     */
    public void updateProgressText(String message)
    {
        progressText.setText(progressText.getText()+message+"\n");
        progressText.updateUI();
    }

    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /*
         * If Nimbus (introduced in Java SE 6) is not available, stay with the
         * default look and feel. For details see
         * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new MainGUI().setVisible(true);
            }
        });
    }
    
    private void updateGUI()
    {
        textPane.setOpaque(true);
        textPane.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        
        btnImport.setOpaque(false);
        btnImport.setBorderPainted(false);
        btnImport.setContentAreaFilled(false);
        
        btnLaunchWebsite.setOpaque(false);
        btnLaunchWebsite.setBorderPainted(false);
        btnLaunchWebsite.setContentAreaFilled(false);
        this.setVisible(true);
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnImport;
    private javax.swing.JButton btnLaunchWebsite;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JTextArea progressText;
    private javax.swing.JScrollPane textPane;
    // End of variables declaration//GEN-END:variables
}
