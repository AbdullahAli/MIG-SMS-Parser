package mig_voting_parser;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/**
 * 
 * @author Abdullah
 * 
 * This is the main "brain" of the system.
 * 
 * This class is responsible for parsing the file, writing it to local storage area
 * as well as logging any invalid votes.
 */
public class Parser 
{
    /**
     * Start the application
     * @param args - message provided to the application on launch.
     */
    public static void main(String[] args) 
    {
        //start the applicaton.
        MainGUI x = new MainGUI();
    }
    
    /** a pattern used to determine if the whole line pattern is accepted **/
    private final Pattern wholeLinePattern = Pattern.compile("^(VOTE) ?[0-9]{10} ?(Campaign:)\\w+ ?(Validity:)\\w+ ?(Choice:)\\w+ ?(CONN:)\\w+ ?(MSISDN:)\\w+ ?(GUID:)\\w+ ?.*(Shortcode:).*");
   
    /** a list used to hold all the possible sub-line patterns **/
    private final ArrayList<String> linePatterns = new ArrayList<>();
    
    /** a list used to hold all the valid votes **/
    private ArrayList<Vote> validVotes = new ArrayList<>();
    
    /** a list used to hold all the invalid votes **/
    private ArrayList<String> invalidVotes = new ArrayList<>();
     
    /**
     * Constructor - the main work of the application is called from here.
     * @param filePath - the filePath of the file to be parsed
     * @param frame - the user GUI
     */
    public Parser(String filePath, MainGUI frame)
    {
        //start a timer
        long startTime = System.currentTimeMillis();
        
        //populate the line patterns
        populateLinePatterns();
        frame.updateProgressText("Parsing file.");
        
        //attempt to parse the file
        parseFile(filePath);
        
        //store the file temporarily - used for high speed insertions into mysql database
        writeToTempFile();
        
        frame.updateProgressText("Exporting data.");
        
        //insert valid votes to database.
        DatabaseAccess databaseAccessor = new DatabaseAccess();
        databaseAccessor.insertVotesToDatabase(validVotes);
        
        //"stop" the timer
        long endTime = System.currentTimeMillis();
        frame.setCanLaunchWebsite(true);
        frame.toFront();
        
        //logg the invalid votes
        logErrors(invalidVotes, frame);
        
        //give user some feedback
        frame.updateProgressText("Done. \nTotal Time: "+((endTime - startTime)/1000)+ " second(s).");
        frame.updateProgressText("("+databaseAccessor.getNumberOfRowsInserted()+" votes inserted)");
    }
    
    /**
     * Used to populate a list with all the possible line patterns
     */
    private void populateLinePatterns()
    {
        linePatterns.add("(( )[0-9]{10})");
        linePatterns.add("Campaign+:(\\w+ ?)");
        linePatterns.add("Validity+:(\\w+ ?)");
        linePatterns.add("Choice:(\\w+ ?[\\w]+ {1})");
        linePatterns.add("CONN+:(\\w+ ?)");
        linePatterns.add("MSISDN+:(\\w+ ?)");
        linePatterns.add("GUID+:(\\w+ ?)");
        linePatterns.add("Shortcode+:(\\w+ ?)");
    }
    
    /**
     * Parses the file
     * @param filePath - the path of the file selected
     */
    private void parseFile(String filePath)
    {
        BufferedReader reader = null;
        try 
        {           
            reader = new BufferedReader(new FileReader(filePath));
            String line = reader.readLine();
            
            //read line by line
            while (line != null) 
            {
                parseLine(line);
                line = reader.readLine();
            }
        }
        catch(Exception ex)
        {
            System.err.println("Error: "+ex.getMessage());
        }
        finally
        {
            if(reader != null)
            {
                try 
                {
                    reader.close();
                } catch (IOException ex) 
                {
                    Logger.getLogger(Parser.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
      
    /**
     * Parses a line according to the pre-set line patterns list
     * @param line - the line to be parsed
     */
    public void parseLine(String line)
    {   
        //does the whole line match our preset pattern?
        if(line.matches(wholeLinePattern.pattern()))
        {
            ArrayList<String> lineData = new ArrayList<>();
            Scanner scanner = new Scanner(line);
            
            //get the required data from the line
            for(String pattern : linePatterns)
            {
                if (scanner.findWithinHorizon(pattern, 0) != null) 
                {   
                    lineData.add(scanner.match().group(1).trim());
                }
            }
            //create strongly typed objects to hold the data
            validVotes.add(new Vote(lineData.get(0), lineData.get(1), lineData.get(2), lineData.get(3), lineData.get(4), 
                    lineData.get(5), lineData.get(6), lineData.get(7)));
        }
        else
        {
            invalidVotes.add(line);
        }   
    }
    
    /**
     * Writes the valid votes to a temporary file.
     * 
     * The file will be used for high speed data inserts into the database.
     */
    private void writeToTempFile()
    {
        BufferedWriter out = null;
        try 
        {   
            //make a writer - with a longish name - to hopfully avoid any overrides.
            out = new BufferedWriter(new FileWriter("tempMigVotesFile.txt"));
            
            //the coloumns are seperated by tabs \t
            //the line is delimited by a new line \n
            for(int i = 0; i < validVotes.size(); i++)
            {
                Vote vote = validVotes.get(i);
                out.append(
                        "''\t"+vote.getEpoch()+ "\t"+vote.getCampaign()+"\t"+vote.getValidity()+"\t"+
                        vote.getChoice()+"\t"+vote.getConn()+"\t"+vote.getMSISDN()+"\t"+
                        vote.getGuid()+"\t"+vote.getShortcode()+"\n"
                        );
            }
        } 
        catch (IOException ex) 
        {
            System.err.println("Error: "+ex.getMessage());
        }
        finally
        {
            if(out != null)
            {
                try {
                    out.close();
                } catch (IOException ex) {
                    Logger.getLogger(Parser.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    /**
     * Logs the invalid votes/ errors into a file
     * @param invalidVotes - the list of invalid votes
     * @param frame - the user GUI
     */
    private void logErrors(ArrayList<String> invalidVotes, MainGUI frame)
    {
        BufferedWriter out = null;
        try
        {
            int errorCounter = 0;
            
            //do no override file - only add to it
            out = new BufferedWriter(new FileWriter("Errors.txt", true));
            for(int i = 0; i < invalidVotes.size(); i++)
            {
                String vote = invalidVotes.get(i);
                
                //record the date and time
                DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                Date date = new Date();
                
                if(!(vote.equals("")))
                {
                    errorCounter++;
                    out.append("@"+dateFormat.format(date)+"--> "+vote);
                    out.newLine();
                }     
            }
            if(errorCounter != 0)
            {
                //notify user about any newly logged errors.
                frame.updateProgressText("Found "+errorCounter+" invalid vote(s).");
            }
        }
        catch(Exception ex)
        {
            System.err.println("Error: "+ex.getMessage());
        }   
        finally
        {
            //house keeping
            if(out != null)
            {
                try {
                    out.close();
                } catch (IOException ex) {
                    Logger.getLogger(Parser.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
}
